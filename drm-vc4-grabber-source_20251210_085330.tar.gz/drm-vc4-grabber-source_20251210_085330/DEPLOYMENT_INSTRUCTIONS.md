# Deployment Instructions for Raspberry Pi 5

## Prerequisites

1. **Raspberry Pi 5** with a 64-bit OS (Raspberry Pi OS 64-bit, Ubuntu, etc.)
2. **Root access** (sudo privileges)
3. **Internet connection** (for Rust installation if needed)

## Deployment Steps

### 1. Transfer Files to Pi

Copy this entire directory to your Raspberry Pi 5:

```bash
# From your local machine:
scp -r drm-vc4-grabber-source_* pi@your-pi-ip:~/

# Or use rsync:
rsync -av drm-vc4-grabber-source_* pi@your-pi-ip:~/
```

### 2. Build on Pi

SSH into your Pi and build the project:

```bash
ssh pi@your-pi-ip
cd drm-vc4-grabber-source_*
./build_on_pi.sh
```

The build script will:
- Check if Rust is installed (install if needed)
- Build the project in release mode
- Set up executable permissions
- Provide next steps

### 3. Test Installation

After building, test the installation:

```bash
# Test basic functionality
sudo ./target/release/drm-vc4-grabber --help

# Run diagnostic test (recommended)
sudo ./diagnostic_test.sh --duration 300

# Run with diagnostic logging
sudo ./target/release/drm-vc4-grabber --diagnostic --verbose
```

### 4. Install as Service (Optional)

To run automatically at boot:

```bash
sudo cp systemd/drm-capture.service /etc/systemd/system/
sudo systemctl daemon-reload
sudo systemctl enable drm-capture.service
sudo systemctl start drm-capture.service
```

## Troubleshooting

### Build Issues

If the build fails:

1. **Update Rust**: `rustup update`
2. **Install dependencies**: `sudo apt update && sudo apt install build-essential`
3. **Check disk space**: `df -h`

### Runtime Issues

If the grabber doesn't work:

1. **Check permissions**: Must run as root (`sudo`)
2. **Check DRM device**: `ls -la /dev/dri/`
3. **Check Kodi status**: `systemctl status kodi`
4. **Run diagnostic test**: `sudo ./diagnostic_test.sh`

### Getting Help

1. Check the diagnostic logs in `diagnostic_logs/`
2. Run with `--verbose` flag for detailed output
3. Check system logs: `dmesg | grep drm`

## Architecture Notes

This version includes:
- **Comprehensive diagnostic system** for stability analysis
- **File-based logging** instead of syslog
- **System monitoring** for Kodi interaction analysis
- **Resource tracking** to detect leaks
- **Automated testing** framework

The diagnostic system is specifically designed to help identify and resolve the Pi 5 stability issues when running alongside Kodi.
