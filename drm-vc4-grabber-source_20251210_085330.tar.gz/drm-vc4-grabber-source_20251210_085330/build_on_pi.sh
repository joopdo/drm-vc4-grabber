#!/bin/bash

# Build script for Raspberry Pi 5
# Run this script on the Pi to build the grabber

set -e

log() {
    echo "[$(date '+%H:%M:%S')] $1"
}

log_error() {
    echo "[$(date '+%H:%M:%S')] ERROR: $1" >&2
}

log_success() {
    echo "[$(date '+%H:%M:%S')] SUCCESS: $1"
}

log_info() {
    echo "[$(date '+%H:%M:%S')] INFO: $1"
}

check_prerequisites() {
    log_info "Checking prerequisites on Raspberry Pi..."
    
    # Check if we're on ARM64
    if [ "$(uname -m)" != "aarch64" ]; then
        log_error "This script should be run on ARM64 (aarch64) architecture"
        log_info "Current architecture: $(uname -m)"
        exit 1
    fi
    
    # Check if Rust is installed
    if ! command -v rustc &> /dev/null; then
        log_error "Rust is not installed. Installing Rust..."
        curl --proto '=https' --tlsv1.2 -sSf https://sh.rustup.rs | sh -s -- -y
        source ~/.cargo/env
        
        if ! command -v rustc &> /dev/null; then
            log_error "Failed to install Rust. Please install manually."
            exit 1
        fi
    fi
    
    log_success "Prerequisites check passed"
    log_info "Rust version: $(rustc --version)"
    log_info "Cargo version: $(cargo --version)"
}

build_project() {
    log_info "Building DRM VC4 Grabber on Raspberry Pi..."
    
    # Clean any previous builds
    if [ -d "target" ]; then
        log_info "Cleaning previous build..."
        cargo clean
    fi
    
    # Build in release mode
    log_info "Building in release mode..."
    if cargo build --release; then
        log_success "Build completed successfully"
    else
        log_error "Build failed"
        exit 1
    fi
    
    # Show build info
    if [ -f "target/release/drm-vc4-grabber" ]; then
        log_success "Binary created: target/release/drm-vc4-grabber"
        log_info "Binary size: $(du -h target/release/drm-vc4-grabber | cut -f1)"
        
        # Make executable
        chmod +x target/release/drm-vc4-grabber
        chmod +x diagnostic_test.sh
        
        echo ""
        echo "=========================================="
        echo "BUILD COMPLETED SUCCESSFULLY"
        echo "=========================================="
        echo "Binary location: target/release/drm-vc4-grabber"
        echo ""
        echo "Next steps:"
        echo "1. Test the grabber:"
        echo "   sudo ./target/release/drm-vc4-grabber --help"
        echo ""
        echo "2. Run diagnostic test:"
        echo "   sudo ./diagnostic_test.sh"
        echo ""
        echo "3. Run with diagnostic logging:"
        echo "   sudo ./target/release/drm-vc4-grabber --diagnostic --verbose"
        echo ""
        echo "4. Install systemd service (optional):"
        echo "   sudo cp systemd/drm-capture.service /etc/systemd/system/"
        echo "   sudo systemctl enable drm-capture.service"
        echo "=========================================="
    else
        log_error "Binary not found after build"
        exit 1
    fi
}

main() {
    log_info "Starting build process on Raspberry Pi 5"
    check_prerequisites
    build_project
    log_success "Build process completed"
}

main "$@"
